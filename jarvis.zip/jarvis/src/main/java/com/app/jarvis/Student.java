package com.app.jarvis;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Student 
{
    private int age;
    private int idno;
 
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
    	System.out.println("result one");
        this.age = age;
    }
    
	public int getIdno() {
		return idno;
	}
	public void setIdno(int idno) {
		System.out.println("result two");
		this.idno = idno;
	}
	
 
}