package com.app.jarvis;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.thoughtworks.xstream.XStream;

@Controller
public class HelloController
    {
		HomeService service = new HomeService();
        @RequestMapping(value="/Structure",method = RequestMethod.POST,  consumes={ "application/xml"} ,  produces={"application/xml"})
        public  @ResponseBody String Structure(@RequestBody Student student) throws SQLException
        {
        	System.out.println("Structure");
        	       	
	    	HashMap<String,Object> map = new HashMap<String,Object>();
	    	map.put("employeeid",student.getIdno());
	    	map.put("age",student.getAge());
	    	map.put("firstName", "ArunKumar");
	    	map.put("lastName", "Veluraj");
	    	map.put("jarco",1);
	    	map.put("jatto","kk");
	    	map.put("emailId", "arun@jarvis.com");
	    	map.put("contactNumber", "9876543210");
	    	map.put("luke","mm");
	    	System.out.println("Firstprint"+map);
	    	
	    	map = service.retrieveService(map,"querytrr");
	   /* 	String insertUpdate = service.insertUpdateService(map,"userDetails");//keyword
	    	String copy = service.copyService(map,"selectinsert");//keyword
	    	  System.out.println("retrieveService"+map);    	
	    	  System.out.println("insertUpdateService"+insertUpdate);  
	    	  System.out.println("copyService"+copy);    */
	    	  
	    	  
	    	  Map<String,Object> mp =map;

	          XStream magicApi = new XStream();
	          magicApi.alias("roottt", Map.class);
	          magicApi.registerConverter(new MapEntryConverter());

	          String xml = magicApi.toXML(mp);
	         
	          System.out.println("Result of newly formed Xml:");
	          System.out.println(xml);
	          return xml;
        }    
    }






