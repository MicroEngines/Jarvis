package com.app.jarvis;

import java.sql.SQLException;
import java.util.HashMap;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;



@Controller
public class HelloController
    {
		HomeService service = new HomeService();
	
        @RequestMapping(value="/Structure",method = RequestMethod.POST,  consumes={ "application/xml"})
       // public  @ResponseBody void hello(@RequestBody Student student)
        public void Structure() throws SQLException
        {
        	System.out.println("Structure");
        	       	
	    	HashMap<String,Object> map = new HashMap<String,Object>();
	    	map.put("firstName", "ArunKumar");
	    	map.put("lastName", "Veluraj");
	    	map.put("emailId", "arun@jarvis.com");
	    	map.put("contactNumber", "9876543210");
	    	
	    	map = service.retrieveService(map,"querytrr");
	    	String insertUpdate = service.insertUpdateService(map,"quertrr");//keyword
	    	String copy = service.copyService(map,"quertrr");//keyword
	    	  System.out.println("retrieveService"+map);    	
	    	  System.out.println("insertUpdateService"+insertUpdate);  
	    	  System.out.println("copyService"+copy);  
	    	
	    	

        	
           
        }
       
      
    }






