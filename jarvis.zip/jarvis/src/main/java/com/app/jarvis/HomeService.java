package com.app.jarvis;
import java.text.SimpleDateFormat;



import java.util.*;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import java.io.*;
import java.sql.SQLException;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

public class HomeService
{

	ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");  
 	JdbcTemplateClass dao=(JdbcTemplateClass)ctx.getBean("edao"); 
 	
 	public String insertUpdateService(HashMap Details,String keyWord) throws SQLException{
 		
 		String comment = dao.dataInsertUpdate(Details,keyWord);
 		 return comment;
 	}
 	
 	public HashMap retrieveService(HashMap Details, String keyWord) throws SQLException{
 		System.out.println("check homeservice");
 		 dao.dataretrive(Details,keyWord);
 		 return Details;
 	}
	
 	public String copyService(HashMap Details,String keyWord) throws SQLException{
 		String comment =  dao.dataCopy(Details,keyWord);
 		 return comment;
 	}
 	
}